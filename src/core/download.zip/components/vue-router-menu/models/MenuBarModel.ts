import { MenuBarItemModel } from "./MenuBarItemModel";

export default interface MenuBarModel {
	items: MenuBarItemModel[];
}