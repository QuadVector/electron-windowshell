import { MenuItemModel } from "./MenuItemModel";

export interface MenuModel {
	items: MenuItemModel[];
}