export interface MenuTheme {
	primary: string;
	secondary: string;
	tertiary: string;
	textColor: string;
	textHoverColor: string;
}