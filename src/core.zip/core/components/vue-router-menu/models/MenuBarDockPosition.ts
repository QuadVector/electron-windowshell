enum MenuBarDockPosition {
	TOP = "TOP",
	LEFT = "LEFT",
	BOTTOM = "BOTTOM",
	RIGHT = "RIGHT",
	NOT_AVAILABLE = "NOT_AVAILABLE"
}

export default MenuBarDockPosition;